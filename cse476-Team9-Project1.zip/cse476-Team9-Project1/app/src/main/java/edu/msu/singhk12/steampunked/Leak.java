package edu.msu.singhk12.steampunked;

import android.content.Context;

public class Leak extends  Pipe {
    /**
     * Constructor for the leak
     * @param context for the leak
     */
    public Leak(Context context) {
        super(false, false, false, false, context, R.drawable.leak);
    }
}
